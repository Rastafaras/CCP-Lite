function RLite(FP_b,SUPER)
  FP_a=activity.getLuaDir(FP_b)
  os.execute("su -c chmod 777 "..FP_a)
  Runtime.getRuntime().exec("su -c "..FP_a)
  print(SUPER)
end

function lite1.OnCheckedChangeListener()
  if lite1.checked then
    RLite("libs/CPP/FITURE1_on","SUPERJAYS")
   else
    RLite("libs/CPP/FITURE1_off","SUPERJAYS")
  end
end

function lite2.OnCheckedChangeListener()
  if lite2.checked then
    RLite("libs/CPP/FITURE2_on","SUPERJAYS")
   else
    RLite("libs/CPP/FITURE2_off","SUPERJAYS")
  end
end

function lite3.OnCheckedChangeListener()
  if lite3.checked then
    RLite("libs/CPP/FITURE3_on","SUPERJAYS")
   else
    RLite("libs/CPP/FITURE3_off","SUPERJAYS")
  end
end

function lite4.OnCheckedChangeListener()
  if lite4.checked then
    RLite("libs/CPP/FITURE4_on","SUPERJAYS")
   else
    RLite("libs/CPP/FITURE4_off","SUPERJAYS")
  end
end