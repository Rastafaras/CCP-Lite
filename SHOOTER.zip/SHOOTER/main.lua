require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "AndLua"
import "http"
import "android.content.Context"
import "android.content.Intent"
import "android.provider.Settings"
import "android.net.Uri"
import "android.content.pm.PackageManager"
import "android.graphics.Typeface"
import "mods"
import "layout"
activity.setContentView(loadlayout(layout))

SUPERZ=activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus=false
SUPERX =WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then SUPERX.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else SUPERX.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
SUPERX.format =PixelFormat.RGBA_8888
SUPERX.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
SUPERX.gravity = Gravity.LEFT| Gravity.TOP
SUPERX.x = 333
SUPERX.y = 333
SUPERX.width = WindowManager.LayoutParams.WRAP_CONTENT
SUPERX.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow = loadlayout(winlay)
minWindow = loadlayout(minlay)
function close.onClick(v)
  HasLaunch=false
  SUPERZ.removeView(mainWindow)
end
isMax=true

function changeWindow()
  if isMax==false then
    isMax=true
    SUPERZ.removeView(minWindow)
    SUPERZ.addView(mainWindow,SUPERX)
   else
    isMax=false
    SUPERZ.removeView(mainWindow)
    SUPERZ.addView(minWindow,SUPERX)
  end end

function Win_minWindow.OnTouchListener(v,event)
  mainWindow.setAlpha(0.4)
  minWindow.setAlpha(0.4)
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstX=event.getRawX()
    firstY=event.getRawY()
    wmX=SUPERX.x
    wmY=SUPERX.y
    isClick=false
    startTime = System.currentTimeMillis()
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    SUPERX.x=wmX+(event.getRawX() - firstX)
    SUPERX.y=wmY+(event.getRawY() - firstY)
    SUPERZ.updateViewLayout(minWindow,SUPERX)
   elseif event.getAction()==MotionEvent.ACTION_UP then
    local endTime = System.currentTimeMillis()
    if endTime-startTime < 100 then
      isClick=false
     else
      isClick=true
    end
    mainWindow.setAlpha(1)
    minWindow.setAlpha(1)
  end
  return
  false
end

function Win_minWindow.onClick(v)
  if isClick==true
   else
    changeWindow()
  end
end

function win_mainview.OnTouchListener(v,event)
  mainWindow.setAlpha(0.4)
  minWindow.setAlpha(0.4)
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstX=event.getRawX()
    firstY=event.getRawY()
    wmX=SUPERX.x
    wmY=SUPERX.y
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    SUPERX.x=wmX+(event.getRawX()-firstX)
    SUPERX.y=wmY+(event.getRawY()-firstY)
    SUPERZ.updateViewLayout(mainWindow,SUPERX)
   elseif event.getAction()==MotionEvent.ACTION_UP then
    mainWindow.setAlpha(1)
    minWindow.setAlpha(1)
  end
  return true
end

function win_move2.OnTouchListener(v,event)
  mainWindow.setAlpha(0.4)
  minWindow.setAlpha(0.4)
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstX=event.getRawX()
    firstY=event.getRawY()
    wmX=SUPERX.x
    wmY=SUPERX.y
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    SUPERX.x=wmX+(event.getRawX()-firstX)
    SUPERX.y=wmY+(event.getRawY()-firstY)
    SUPERZ.updateViewLayout(mainWindow,SUPERX)
   elseif event.getAction()==MotionEvent.ACTION_UP then
    mainWindow.setAlpha(1)
    minWindow.setAlpha(1)
  end
  mainWindow.setAlpha(1)
  minWindow.setAlpha(1)
  return true
end

function showMenu.onClick()
  if HasLaunch==true
    then
    return
   else
    if Settings.canDrawOverlays(activity)
      then
     else
      intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
      intent.setData(Uri.parse("package:" .. this.getPackageName())); this.startActivity(intent);
    end
    HasLaunch=true
    local ret={pcall(function()
        SUPERZ.addView(mainWindow,SUPERX)
      end)}
    if ret[1]==false
      then
    end
  end import "java.io.*" file,err=io.open("/data/data/in.shooter.org/files/value.lua")
  if err==nil
    then
   else
  end
end

function getroot.onClick()
  os.execute("su")
end

function startgame.onClick()
  this.startActivity(activity.getPackageManager().getLaunchIntentForPackage("com.tencent.iglite"));
end

function CircleButton(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(5, InsideColor1)
  view.setBackgroundDrawable(drawable)
end
CircleButton(win_mainview,0xFF2B2B2B,0,0xFF0084FF)
CircleButton(cmz,0xFF2B2B2B,0,0xFF0084FF)
CircleButton(win_move1,0xFF2B2B2B,0,0xFF0084FF)

superjays.setTypeface(Typeface.DEFAULT_BOLD)
win_move2.setTypeface(Typeface.DEFAULT_BOLD)
t1.setTypeface(Typeface.DEFAULT_BOLD)
t2.setTypeface(Typeface.DEFAULT_BOLD)
t3.setTypeface(Typeface.DEFAULT_BOLD)

lite1.setTypeface(Typeface.DEFAULT_BOLD)
lite2.setTypeface(Typeface.DEFAULT_BOLD)
lite3.setTypeface(Typeface.DEFAULT_BOLD)
lite4.setTypeface(Typeface.DEFAULT_BOLD)

import "value"